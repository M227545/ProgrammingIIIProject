﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace AT3Project
{
    class Hash
    {
        private static string hash;
        private static byte[] salt = new byte[64];


        //Salt and hash the text.
        public static void SaltHash(string input)
        {
            //Get the salt.
            var RNGProv = new RNGCryptoServiceProvider();
            RNGProv.GetNonZeroBytes(salt);

            //Hash the input.
            var keyMaker = new Rfc2898DeriveBytes(input, salt, 100);
            hash = Convert.ToBase64String(keyMaker.GetBytes(256));
        }

        //Salt and hash new input then compare the two.
        public static bool Compare(string input)
        {
            //Hash the new input.
            var keyMaker = new Rfc2898DeriveBytes(input, salt, 100);

            //Return the comparison.
            return Convert.ToBase64String(keyMaker.GetBytes(256)) == hash;
        }
    }
}
