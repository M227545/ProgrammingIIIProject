﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AT3Project
{
    public partial class Form1 : Form
    {
        //Linked list used to hold names of countries.
        private LinkedList<string> countryList = new LinkedList<string>();
        //The currently selected node.
        private LinkedListNode<string> countryNode;

        public Form1()
        {
            InitializeComponent();

            //Read entries from the "Words.csv" file.
            Words.ReadCSV();
            //Write the entries to the list box in the GUI.
            Display();

            //List of country names
            countryList.AddLast("Andorra");
            countryList.AddLast("Belarus");
            countryList.AddLast("Cyprus");
            //Set the current node to the first entry (Andorra).
            countryNode = countryList.First;
            //Set the label to the value of the current node.
            lblCountry.Text = countryNode.Value;
        }

        //A foreach loop to add the entries to the listbox.
        private void Display()
        {
            lstWords.Items.Clear();

            foreach (string word in Words.wordsArray)
            {
                lstWords.Items.Add(word);
            }
        }

        //Sort the word entries using the Mergesort.
        private void btnSort_Click(object sender, EventArgs e)
        {
            //Call the method from the Words class.
            Words.MergeSort(0, Words.wordsArray.Length - 1);

            //Update the listbox.
            Display();

            //Clear the textbox.
            txtSearch.Text = "";

            //The list can be searched now that it is sorted.
            btnSearch.Enabled = true;
            txtSearch.Enabled = true;
        }
        
        //Search the listbox using the Binary search.
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //Call the method from the Words class and return the result.
            int result = Words.BinarySearch(txtSearch.Text);

            //If the result is not an index value, display an error.
            if (result == -1)
            {
                MessageBox.Show("Result not found.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            //Otherwise, the entry was found.
            else
            {
                //Highlight the result.
                lstWords.SelectedIndex = result;
                //Clear the textbox.
                txtSearch.Text = "";
            }
        }

        //Scroll to the previous country in the list.
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //If we are not already at the start of the list, switch to the previous node.
            if (countryNode != countryList.First)
            {
                countryNode = countryNode.Previous;
                lblCountry.Text = countryNode.Value;
            }
            //Otherwise, display an error.
            else
            {
                MessageBox.Show("Start of the list reached.", "Cannot go further",MessageBoxButtons.OK, MessageBoxIcon.Information);
                countryNode = countryList.First;
            }
        }

        //Scroll to the next country in the list.
        private void btnNext_Click(object sender, EventArgs e)
        {
            //If we are not already at the end of the list, switch to the next node.
            if (countryNode != countryList.Last)
            {
                countryNode = countryNode.Next;
                lblCountry.Text = countryNode.Value;
            }
            //Otherwise, display an error.
            else
            {
                MessageBox.Show("End of the list reached.", "Cannot go further", MessageBoxButtons.OK, MessageBoxIcon.Information);
                countryNode = countryList.Last;
            }
        }

        //Hash the text in above textbox.
        private void btnHash_Click(object sender, EventArgs e)
        {
            //If the texbox is not empty, hash the text.
            if (!String.IsNullOrWhiteSpace(txtHashing.Text))
            {
                //Call the method from the Hash class.
                Hash.SaltHash(txtHashing.Text);
                MessageBox.Show("Successfully hashed string.","Hashed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtHashing.Clear();
            }
            //Otherwise, display an error.
            else
            {
                MessageBox.Show("Textbox is empty, could not hash.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Compare the current text to the previously hashed text.
        private void btnCompare_Click(object sender, EventArgs e)
        {
            //If the strings match, notify the user.
            if (Hash.Compare(txtHashing.Text))
            {
                MessageBox.Show("Current string matches previous.", "Successfully matched", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Otherwise, display an error.
            else
            {
                MessageBox.Show("Current string does not match previous.", "Unsuccessfully matched", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            txtHashing.Clear();
        }
    }
}
