﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using CsvHelper;
using System.Windows.Forms;

namespace AT3Project
{
    class Words
    {
        //The header for reading the CSV.
        public string word { get; set; }
        //The array to thold the word entries.
        public static string[] wordsArray;

        //Read the entries in the CSV file.
        public static void ReadCSV()
        {
            //If the file is found, add the entries to the array.
            try
            {
                //Uses CSVHelper to read the CSV.
                using (StreamReader sr = new StreamReader("Words.csv"))
                using (CsvReader csv = new CsvReader(sr, System.Globalization.CultureInfo.CurrentCulture))
                {
                    //Get the entries.
                    List<Words> wordList = csv.GetRecords<Words>().ToList();

                    //Set the size of the array to the number of entries.
                    wordsArray = new string[wordList.Count];

                    //Add all entries to the array.
                    for (int count = 0; count < wordList.Count; count++)
                    {
                        wordsArray[count] = wordList[count].word;
                    }
                }
            }
            //Otherwise, display an error.
            catch
            {
                MessageBox.Show("CSV file couldn't be read.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Close the program.
                Environment.Exit(1);
            }
        }

        //The Merge sort is used on the word list.
        public static void MergeSort(int left, int right)
        {
            if (left < right)
            {
                int middle = left + (right - left) / 2;

                //Sort the left.
                MergeSort(left, middle);
                //Sort the right.
                MergeSort(middle + 1, right);

                //Run the rest of the sort.
                MergeSort2(left, middle, right);
            }
        }

        //Sorts the parts created by the previous method.
        private static void MergeSort2(int left, int middle, int right)
        {
            int count;
            int count2;
            int leftCount;
            int leftLength = middle - left + 1;
            int rightLength = right - middle;
            string[] leftArray = new string[leftLength];
            string[] rightArray = new string[rightLength];

            //Add items to leftArray.
            for (count = 0; count < leftLength; count++)
            {
                leftArray[count] = wordsArray[left + count];
            }

            //Add items to rightArray.
            for (count2 = 0; count2 < rightLength; count2++)
            {
                rightArray[count2] = wordsArray[middle + 1 + count2];
            }

            count = 0;
            count2 = 0;
            leftCount = left;

            //While the subarrays have items inside, add the lowest value to the main array.
            while (count < leftLength && count2 < rightLength)
            {
                if (rightArray[count2].CompareTo(leftArray[count]) >= 0)
                {
                    wordsArray[leftCount] = leftArray[count];
                    count++;
                }
                else
                {
                    wordsArray[leftCount] = rightArray[count2];
                    count2++;
                }

                leftCount++;
            }

            //While the left subarray has items inside, add items to main array.
            while (count < leftLength)
            {
                wordsArray[leftCount] = leftArray[count];
                count++;
                leftCount++;
            }

            //While the right subarray has items inside, add items to main array.
            while (count2 < rightLength)
            {
                wordsArray[leftCount] = rightArray[count2];
                count2++;
                leftCount++;
            }
        }

        //Binary search is used to find entries in the word list.
        public static int BinarySearch(string target)
        {
            int left = 0;
            int right = wordsArray.Length - 1;

            //While there are items to search, keep running.
            while (left <= right)
            {
                //Find the middle.
                int mid = left + (right - left) / 2;

                //If a result is found at the middle, return that.
                if (wordsArray[mid] == target)
                {
                    return mid;
                }
                //If the target value is higher than the middle, search the right side.
                if (wordsArray[mid].CompareTo(target) < 0)
                {
                    left = mid + 1;
                }
                //Otherwise the target value is lower than the middle, search the left side.
                else
                {
                    right = mid - 1;
                }
            }

            //If nothing is found, return -1.
            return -1;
        }
    }
}
